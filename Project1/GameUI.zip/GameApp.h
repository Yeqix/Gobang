//#ifndef GOMOKU_GAMEAPP_H
//#define GOMOKU_GAMEAPP_H
//#include "GameUI.h"
//class GameApp
//{
//public:
//	GameApp();
//	void Run();
//private:
//	GomokuUI ui;               //ʹ��ԭ�е�GameUI
//	GameState currentState;    //��Ϸ״̬
//	void handleSinglePlayer();
//	void handleMultiPlayer();
//};
//#endif